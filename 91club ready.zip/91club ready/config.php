<?php
/*
This file contains database config.phpuration assuming you are running mysql using user "root" and password ""
*/

define('DB_SERVER', 'mysql.thecryptonews.site')
define('DB_USERNAME', 'u280619928_sayan_parna');
define('DB_PASSWORD', 'Pritam@2001.
define('DB_NAME', 'u280619928_colour_game')

// Try connecting to the Database
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

//Check the connection
if($conn == false){
    dir('Error: Cannot connect');
    Echo"Fail";
}

?>